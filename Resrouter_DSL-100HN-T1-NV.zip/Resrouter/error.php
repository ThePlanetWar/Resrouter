<title>Resrouter 0.1</title>
<link rel="stylesheet" href="css/materialize.min.css">
<style>

.spinner {
  width: 140px;
  height: 140px;
  margin: 100px auto;
  background-color: #ffffff;

  border-radius: 100%;  
  -webkit-animation: sk-scaleout 1.0s infinite ease-in-out;
  animation: sk-scaleout 1.0s infinite ease-in-out;
}

@-webkit-keyframes sk-scaleout {
  0% { -webkit-transform: scale(0) }
  100% {
    -webkit-transform: scale(1.0);
    opacity: 0;
  }
}

@keyframes sk-scaleout {
  0% { 
    -webkit-transform: scale(0);
    transform: scale(0);
  } 100% {
    -webkit-transform: scale(1.0);
    transform: scale(1.0);
    opacity: 0;
  }
}
@import url('https://fonts.googleapis.com/css?family=Roboto');
body{font-family: 'Roboto', sans-serif;background-color:#80CBC4;}

</style>
<script type="text/javascript" language="javascript" src="jquery-1.3.2.js"></script>
<script type="text/javascript" language="javascript">
$(function($) {
  $("#formulario").submit(function() {
    var post_foto = $("#post_foto").val();
    var quantidade = $("#quantidade").val();
    var mensagem = $("#mensagem").val();
    $("#status").html("<center><h1><div class='spinner'></div>");
    $.post('gera.php', {post_foto: post_foto, quantidade: quantidade }, function(resposta) {
        if (resposta != false) {
          $("#status").html('<center><h3><font color="#1B5E20"> ' + resposta + '');
          
        }
    });
  });
});

</script>
</head>

<body>

<div id="escrever">
  <center>
  <img src="logo.png" width="220" height="50">
  <strong><h5><font color="red">Senha ou Usuário do router não confere</font><h5></strong> <br />
  <meta http-equiv="refresh" content="3;URL=index.php"> 
        <center><h5>By ThePlanetWar | NatanPC</h5></br>


    </form>
</div>
<div id="status"></div>
</div>
</body>
</html>
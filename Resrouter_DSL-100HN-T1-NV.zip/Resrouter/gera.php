<?php
//parte que faz a comunicação com o arquivo que controla o roteador e muda o ip..
$dominio= $_SERVER['HTTP_HOST'];
$cookielogin = $_COOKIE['roteador_session'];
$curl2 = curl_init();
	curl_setopt_array($curl2, array(
    CURLOPT_TIMEOUT => 1,
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => "http://{$dominio}/Resrouter/controle.php?cookie={$cookielogin}"
));
$resp2 = curl_exec($curl2);
curl_close($curl2);
echo $resp2;
//

//função para descobrir quando internet voltou, e pega o novo ip.
descobrir_ip();
function descobrir_ip()
 {
    $curl = curl_init();
	curl_setopt_array($curl, array(
    CURLOPT_CONNECTTIMEOUT  => 50,
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => 'https://api.ipify.org/?format=json'
	));
	$resp = curl_exec($curl);
	curl_close($curl);
    $ip_json = json_decode($resp);
	$msg = $ip_json->ip;

	if (!empty($msg)) {
      echo 'Seu novo ip é: ' . $msg . '!</br>';
    } else {
      descobrir_ip();
    }
	return;

}
 //    
?>
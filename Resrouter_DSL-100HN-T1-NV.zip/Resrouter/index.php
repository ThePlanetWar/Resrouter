<?php
require_once 'Mink/vendor/autoload.php';

//parte para definir a versão e router compativel com o resrouter
$router = "DSL-100HN-T1-NV";
$firmware_router = "BR_SO_113WUK0b8";
$res_version = "0.1 Alpha";
//

use \Wa72\HtmlPageDom\HtmlPageCrawler;
$driver = new \Behat\Mink\Driver\GoutteDriver();
$client = new \Behat\Mink\Session($driver);

//verifica se o login ainda esta ativo
@$cookie = $_COOKIE['roteador_session'];
$escapedValue = "session_gblsessionKey";
$client->start();
$client->setCookie("SESSIONID", "$cookie");
$client->visit('http://192.168.15.1/cgi-bin/sessionkey.cgi');
$page = $client->getPage();

$topLink = $page->find('named_exact', array('id', $escapedValue));
if (!empty($topLink)) {
      $verifica_cookie = $topLink->getValue();
    } else {
      $verifica_cookie = "expirado";
    }

$client->stop();
//

//verifica ip cliente
$curl = curl_init();
  curl_setopt_array($curl, array(
    CURLOPT_CONNECTTIMEOUT  => 50,
    CURLOPT_RETURNTRANSFER => 1,
    CURLOPT_URL => 'https://api.ipify.org/?format=json'
  ));
  $resp = curl_exec($curl);
  curl_close($curl);
  $ip_json = json_decode($resp);
  $ip_atual = $ip_json->ip;
//
?>
<title>Resrouter 0.1</title>
<link rel="stylesheet" href="css/materialize.min.css">
<style>

.spinner {
  width: 140px;
  height: 140px;
  margin: 100px auto;
  background-color: #ffffff;

  border-radius: 100%;  
  -webkit-animation: sk-scaleout 1.0s infinite ease-in-out;
  animation: sk-scaleout 1.0s infinite ease-in-out;
}

@-webkit-keyframes sk-scaleout {
  0% { -webkit-transform: scale(0) }
  100% {
    -webkit-transform: scale(1.0);
    opacity: 0;
  }
}

@keyframes sk-scaleout {
  0% { 
    -webkit-transform: scale(0);
    transform: scale(0);
  } 100% {
    -webkit-transform: scale(1.0);
    transform: scale(1.0);
    opacity: 0;
  }
}
@import url('https://fonts.googleapis.com/css?family=Roboto');
body{font-family: 'Roboto', sans-serif;background-color:#80CBC4;}

</style>
<script type="text/javascript" language="javascript" src="jquery-1.3.2.js"></script>
<script type="text/javascript" language="javascript">
$(function($) {
  $("#formulario").submit(function() {
    var post_foto = $("#post_foto").val();
    var quantidade = $("#quantidade").val();
    var mensagem = $("#mensagem").val();
    $("#status").html("<center><h1><div class='spinner'></div>");
    $.post('gera.php', {post_foto: post_foto, quantidade: quantidade }, function(resposta) {
        if (resposta != false) {
          $("#status").html('<center><h3><font color="#1B5E20"> ' + resposta + '');
          
        }
    });
  });
});

</script>
</head>

<body>

<div id="escrever">
  <center>
  <img src="logo.png" width="220" height="50">
  <strong><h5>Seu ip atual: <?php echo $ip_atual;?><h5></strong> <br />
 <?php
 // segunda parte da verificação do login
 $expirado = "expirado";
 if(strpos("[".$expirado."]", "$verifica_cookie"))
    {
    echo 'Faça seu login</br><form action="login.php" method="post"><input name="user" placeholder="Usuario router" type="text"></br><input placeholder="Senha" name="pass" type="password"><button class="btn waves-effect waves-light" type="submit">Fazer login
  </button></form>';
    }
else
    {
    echo '<form id="formulario" action="javascript:func()" method="post"><button class="btn waves-effect waves-light" type="submit" name="javascript:func()">Trocar ip!
  </button>';
    } 

    ?>
        <center><h5>By ThePlanetWar | NatanPC</h5></br>
        <h6>Adaptado para o Router: <?php echo $router;?></h6>
        <h6>Firmware Version: <?php echo $firmware_router;?></h6>
        <h6>Resrouter Version: <?php echo $res_version;?></h6></center>

    </form>
</div>
<div id="status"></div>
</div>
</body>
</html>
<?php
require_once 'Mink/vendor/autoload.php';
use \Wa72\HtmlPageDom\HtmlPageCrawler;
$driver = new \Behat\Mink\Driver\GoutteDriver();
$client = new \Behat\Mink\Session($driver);
$desativa = new \Behat\Mink\Session($driver);
$ativa = new \Behat\Mink\Session($driver);
$cookielogin = $_GET['cookie'];

// entra no painel do router e desativa conexão
$desativa->start();
$desativa->setCookie('SESSIONID', $cookielogin);
$desativa->visit('http://192.168.15.1/cgi-bin/pages/network/broadband/script/ip_down_0.cgi');
$desativa->stop();
//

// entra no painel do router e ativa conexão
$ativa->start();
$ativa->setCookie('SESSIONID', $cookielogin);
$ativa->visit('http://192.168.15.1/cgi-bin/pages/network/broadband/script/ip_up_0.cgi');
$ativa->stop();
//


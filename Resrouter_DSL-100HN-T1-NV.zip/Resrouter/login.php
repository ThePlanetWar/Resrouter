<?php
require_once 'Mink/vendor/autoload.php';
$driver = new \Behat\Mink\Driver\GoutteDriver();
$client = new \Behat\Mink\Session($driver);


//recebe dados de login
$usuario = $_POST['user'];
$senha = $_POST['pass'];

//função criptografia md5 para login no router DSL-100HN-T1-NV
$senha_md5 = $senha;
$codificada_senhamd5 = md5($senha_md5);
$hashfinal_md5 = "{$usuario}:{$codificada_senhamd5}";

//função criptografia base64 para login no router DSL-100HN-T1-NV
$hashfinal = base64_encode($hashfinal_md5);
$url = "http://192.168.15.1/cgi-bin/index.asp?{$hashfinal}";

//tenta fazer o login e resgata o cookie
function login_router($url)
 {
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_COOKIEJAR, "cookies.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "cookies.txt");

$output = curl_exec($ch);
$info = curl_getinfo($ch);
curl_close($ch);
		
}
login_router($url);
$ch = curl_init('http://192.168.15.1/cgi-bin/sessionkey.cgi');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

// pega o cookie e salva em uma variavel
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_COOKIEJAR, "cookies.txt");
$result = curl_exec($ch);
curl_close($ch);
preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $result, $matches);
$cookies = array();
foreach($matches[1] as $item) {
    parse_str($item, $cookie);
    $cookies = array_merge($cookies, $cookie);
}
$cookie_json = json_encode($cookies);
$cookie_json = json_decode($cookie_json);
$cookie_final = $cookie_json->{'SESSIONID'};
//

//parte que chama função para validar o cookie
login_router($url);
//

//seta o cookie do roteador no Resrouter
setcookie("roteador_session", $cookie_final);
//

//funcao que apaga o arquivo txt com o cookie
unlink("cookies.txt");
//

//função que valida o user e senha
$escapedValue = "session_gblsessionKey";
$client->start();
$client->setCookie("SESSIONID", "$cookie_final");
$client->visit('http://192.168.15.1/cgi-bin/sessionkey.cgi');
$page = $client->getPage();

$topLink = $page->find('named_exact', array('id', $escapedValue));
if (!empty($topLink)) {
      $verifica_cookie = $topLink->getValue();
    } else {
      $verifica_cookie = "expirado";
    }

$client->stop();
$expirado = "expirado";
 if(strpos("[".$expirado."]", "$verifica_cookie"))
    {
    header("location:error.php");
    }
else
    {
    header("location:index.php");
    } 


//